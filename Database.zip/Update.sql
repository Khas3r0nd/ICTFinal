 --1.Update the name of restaurants--
 UPDATE Restaurants
 SET name = 'Dinner in the Sky'
 WHERE RestaurantID = 1;

 UPDATE Restaurants
 SET name = 'The Lockhart'
 WHERE RestaurantID = 2;

 UPDATE Restaurants
 SET name = 'El Diablo “The Devil”'
 WHERE RestaurantID = 3;

 UPDATE Restaurants
 SET name = 'Eternity'
 WHERE RestaurantID = 4;

 UPDATE Restaurants
 SET name = 'O.NOIR'
 WHERE RestaurantID = 5;

 UPDATE Restaurants
 SET name = 'Aurum'
 WHERE RestaurantID = 6;

 UPDATE Restaurants
 SET name = 'Kinderkookkafe'
 WHERE RestaurantID = 7;

 UPDATE Restaurants
 SET name = 'Steam Plant'
 WHERE RestaurantID = 8;

 UPDATE Restaurants
 SET name = 'Chill Out'
 WHERE RestaurantID = 9;

 UPDATE Restaurants
 SET name = 'Villa Escudero'
 WHERE RestaurantID = 10;

 --2. Update table JobDescription salary range column--
 UPDATE JobDescription
 SET salary_range = '44000-70000'
 WHERE JobID = 1;

 UPDATE JobDescription
 SET salary_range = '23700-45000'
 WHERE JobID = 2;

 UPDATE JobDescription
 SET salary_range = '20500-30000'
 WHERE JobID = 3;

 UPDATE JobDescription
 SET salary_range = '27000-40000'
 WHERE JobID = 4;

 UPDATE JobDescription
 SET salary_range = '24500-35000'
 WHERE JobID = 5;

 UPDATE JobDescription
 SET salary_range = '51800-72000'
 WHERE JobID = 6;

 UPDATE JobDescription
 SET salary_range = '63000-78000'
 WHERE JobID = 7;

 UPDATE JobDescription
 SET salary_range = '79000-90000'
 WHERE JobID = 8;

 UPDATE JobDescription
 SET salary_range = '32000-55000'
 WHERE JobID = 9;

 UPDATE JobDescription
 SET salary_range = '31000-50000'
 WHERE JobID = 10;

--3.Update employee's salary whose working experience more than 5 years--
 update Employees set salary = salary*1.2
 where Employees.working_experience::integer>5;

--4.Set hotel rate 5 for hotels with rate greater than 4.5
UPDATE hotel
SET rate = 5.0
WHERE rate > 4.5;

--5.Update price column where type Lux to 50 percent--
UPDATE Room
SET price = price * 1.5
WHERE type = 'Lux';

--6.Update manager's contact_number whose managerID is 10111--
UPDATE managers
set contact_number = '(561) 758-4567'
WHERE ManagerID = 10111;

--7.Add 5 days to reservation for hotels that have less than 4 stars--
UPDATE reservation
SET number_of_day = number_of_day + 5
WHERE hotelid NOT IN (
    SELECT hotelid
    FROM hotel
    WHERE rate > 4)

--8. Change the information about user because previous one was incorrect--
UPDATE users
SET name = 'Naruto',surname = 'Uzumaki',gender = 'Male'
WHERE userID = 1502;

--9. Update salary range for Executive Chef
UPDATE jobdescription
SET salary_range = '55000-80000'
WHERE name = 'Executive Chef';

--10.Update price of Additional services that cost $15
UPDATE additionalservices
SET price = '$20'
WHERE price = '$15';





