--1.Delete additional services that have age limitation from 18 years old
DELETE FROM additionalservices
WHERE age_limitations = 'from the age of 18';

--2.Delete services for hotels with age limitation from 18 years old
DELETE FROM hotel_service
WHERE serviceid IN (
    SELECT serviceid
    FROM additionalservices
    WHERE age_limitations = 'from the age of 18'
);

--3.Delete services for users with age limitation from 18 years old
DELETE FROM userservice
WHERE serviceid IN (
    SELECT serviceid
    FROM additionalservices
    WHERE age_limitations = 'from the age of 18'
);

--4.Delete employees whose managers have less than 4 years working experience
DELETE FROM employees
WHERE managerid NOT IN (
    SELECT managerid
    FROM managers
    WHERE working_experience::integer < 4
);

--5.Delete managers who have less than 4 years working experience
DELETE FROM managers
WHERE working_experience::integer < 4;

--6.Delete user services where user name starts with letter "D"
DELETE FROM userservice
WHERE UserID IN (
    SELECT userid
    FROM users
    WHERE name LIKE 'D%');

--7.Delete user dishes where user name starts with letter "D"
DELETE FROM dishuser
WHERE UserID IN (
    SELECT userid
    FROM users
    WHERE name LIKE 'D%');

--8.Delete users whose name starts with letter "D"
DELETE FROM users
WHERE name LIKE 'D%';

--9.Delete reservations that are not belong to any user
DELETE FROM reservation
WHERE reservationid NOT IN (
    SELECT reservationid
    FROM users
);

--10.Delete from records from dish user where dish costs more than 35
DELETE FROM dishuser
WHERE dishid IN (
    SELECT Menu.DishID
    FROM menu
    WHERE price > 35
);

--11.Delete dishes that cost more than 35
DELETE FROM menu
WHERE price > 35;

--12.Delete restaurants that does not have any dishes
DELETE FROM restaurants
WHERE restaurantid NOT IN (
    SELECT restaurantid
    FROM menu
);

--13.Delete rooms that are not reserved by anyone
DELETE FROM room
WHERE roomid NOT IN (
    SELECT roomid
    FROM reservation
);

--14.Delete job description for jobs that nobody works
DELETE FROM jobdescription
WHERE jobid NOT IN (
    SELECT jobid
    FROM employees
);