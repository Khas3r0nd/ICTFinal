--Hotel managing system


CREATE TABLE  Hotel (
 HotelID INT PRIMARY KEY,
 name VARCHAR(25),
 rate DECIMAL(5,2),
 reception_number VARCHAR(60),
 address VARCHAR(255)
);

CREATE TABLE Room(
 RoomID INT,
 number_of_beds INT,
 type VARCHAR(25),
 rate DECIMAL(5,2),
 price DECIMAL(10,2),
 HotelID INT,
 FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID) --This foreign key is used to now in which hotel this room is placed
);
ALTER TABLE Room ADD PRIMARY KEY (RoomID);

CREATE TABLE Reservation (
 ReservationID INT,
 number_of_day INT,
 RoomID INT,
 HotelID INT,
 FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID), --This foreign key is used to know in which hotel
 FOREIGN KEY (RoomID) REFERENCES Room(RoomID) --And which room was reservated
);
ALTER TABLE Reservation ADD PRIMARY KEY (ReservationID);

CREATE TABLE Users (
 UserID INT PRIMARY KEY,
 name VARCHAR (255),
 surname VARCHAR (255),
 gender VARCHAR(11),
 contact_number VARCHAR(60),
 HotelID INT,
 ReservationID INT,
 FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID), --Foreign key is used to know in which hotel user is leaving
 FOREIGN KEY (ReservationID) REFERENCES Reservation(ReservationID) --And what is reservationID, by reservationID we can find his room
);

CREATE TABLE Managers (
 ManagerID INT PRIMARY KEY,
 name VARCHAR(255),
 surname VARCHAR(255),
 contact_number VARCHAR(60),
 working_experience VARCHAR(5),
 salary DECIMAL (12,4),
 HotelID INT,
 FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID) --Foreign key is used to know in which hotel manager working
);

CREATE TABLE JobDescription(
 JobID INT PRIMARY KEY,
 name VARCHAR(100),
 description VARCHAR (255),
 salary  DECIMAL (12,4),
 skills VARCHAR (100)
);

CREATE TABLE Employees (
 EmployeeID INT PRIMARY KEY,
 name VARCHAR (255),
 surname VARCHAR(255),
 contact VARCHAR (60),
 marital_status VARCHAR (30),
 working_experience VARCHAR(10),
 salary decimal,
 JobID INT,
 ManagerID INT,
 HotelID INT,
 FOREIGN KEY (JobID) REFERENCES JobDescription(JobID), --Foreign key is used to get info about employees job
 FOREIGN KEY (ManagerID) REFERENCES Managers(ManagerID), --Foreign key is used to know who is the manager of this employee
 FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID) --Foreign key is used to know in which hotel worker works
);


CREATE TABLE Restaurants (
 RestaurantID INT PRIMARY KEY,
 floor VARCHAR(122),
 number_of_tables VARCHAR(255),
 HotelID INT,
 FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID) --Foreign key is used to know in which hotel this restaurant is placed
);

CREATE TABLE Menu(
 DishID INT PRIMARY KEY,
 name VARCHAR (255),
 description VARCHAR(255),
 price DECIMAL(10,2),
 RestaurantID INT,
 FOREIGN KEY (RestaurantID) REFERENCES Restaurants(RestaurantID) --Foreign key is used to store in which restaurant this dish can be ordered
);

 CREATE TABLE DishUser( --This whole table is used to track user's order
 ID INT PRIMARY KEY,
 DishID INT,
 UserID INT,
 FOREIGN KEY (DishID) REFERENCES Menu(DishID), --It will take dishID from Dishes table
 FOREIGN KEY (UserID) REFERENCES Users(UserID) --It will take userID from Users table
);

 CREATE TABLE AdditionalServices (
 ServiceID INT,
 name VARCHAR(255),
 description VARCHAR(255),
 price VARCHAR(255),
 age_limitations VARCHAR(255),
 PRIMARY KEY(ServiceID)
);

 CREATE TABLE hotel_service(
 ServiceID INT,
 HotelID INT,
 FOREIGN KEY (ServiceID) REFERENCES AdditionalServices (ServiceID),
 FOREIGN KEY (HotelID) REFERENCES Hotel (HotelID),
 PRIMARY KEY (ServiceID,HotelID)
);

 CREATE TABLE UserService ( --This whole table is used to track which user was using services and what services did user used
 ID INT PRIMARY KEY,
 ServiceID INT,
 UserID INT,
 FOREIGN KEY (ServiceID) REFERENCES AdditionalServices(ServiceID), --This foreign key is used to take ID of additional service
 FOREIGN KEY (UserID) REFERENCES Users(UserID) -- This will take ID from Users table
);

 ALTER TABLE Restaurants
 ALTER COLUMN HotelID set not null;

 ALTER TABLE Employees
 ADD COLUMN satisfied boolean;

 ALTER TABLE Employees
 DROP COLUMN satisfied;

 --Create new column with datatype varchar--
 ALTER TABLE Restaurants
 ADD COLUMN name varchar;

 --Change name salary to salary_range and change it's datatype
 ALTER TABLE JobDescription RENAME COLUMN salary TO salary_range;
 ALTER TABLE JobDescription
 ALTER COLUMN salary_range TYPE VARCHAR;

 INSERT INTO Hotel (HotelID, name, rate, reception_number, address) VALUES
(101, 'Empire State Hotel', 4.8, '+40 (07) 3114 7440', '311 Onsgard Circle'),
(102, 'Brownstone Hotel', 4.89, '+39 (08) 0774 1500', '185 Glacier Hill Parkway'),
(103, 'Paramount Hotel', 4.55, '+43 (0) 6413 8202', '29 Armistice Street'),
(104, 'Quick Stop Hotel', 4.67, '+70 (03) 2547 3658', '60 Monument Point'),
(105, 'Eighth Avenue Hotel', 4.72, '+30 (70) 3625 7584', '826 Bayside Point'),
(106, 'Clairmont Hotel', 3.99, '+28 (04) 9568 2451', '1 Nevada Parkway'),
(107, 'Sunshine Hotel', 3.78, '+42 (0) 2414 6258', '558 Carioca Pass'),
(108, 'Atlantic Hotel', 4.31, '+37 (03) 9564 5942', '341 John Wall Way'),
(109, 'Hillside Hotel', 4.52, '+29 (05) 3512 5214', '9 Grover Lane'),
(110, 'Indian Horse Hotel', 4.09, '+38 (02) 3621 7541', '663 Hermina Point');

 INSERT INTO Managers (ManagerID, name, surname, contact_number, working_experience, salary,HotelID)
 VALUES
 (10101, 'Ashlen', 'Sudron', '(541)754-3010', 7, 150000,101),
 (10102, 'Brendan', 'Mousley', '(211) 741-2010', 2, 60000,102),
 (10103, 'Rose', 'Shear', '(541) 544-9852', 3, 70000,103),
 (10104, 'Freddie', 'Lockner', '(931) 784-3601', 4, 60000,104),
 (10105, 'Billy', 'Barthram', '(521) 236-4520', 5, 120000,105),
 (10106, 'Westbrooke', 'O Cassidy', '(341) 754-3096', 6, 140000,106),
 (10107, 'Bryn', 'Matschoss', '(321) 630-3684', 3, 77000,107),
 (10108, 'Charmain', 'Meatcher', '(528) 221-1340', 3, 65000,108),
 (10109, 'Meryl', 'Rowcastle', '(561) 758-4567', 4, 65000,109),
 (10110, 'Viole', 'Chilton', '(541) 654-9541', 5, 120000,110),
 (10111, 'Brook', 'Python', '(541) 365-9874', 8, 180000,110),
 (10112, 'Fraser', 'Rickesies', '(532) 635-3210', 3, 64000,102),
 (10113, 'Alexander', 'Bunclark', '(595) 854-2360', 6, 100000,NULL),
 (10114, 'Georgeta', 'Lough', '(812) 542-2011', 9, 200000,NULL);

 INSERT INTO JobDescription (JobID, name, description, salary_range, skills)
 VALUES
 (01, 'Assistant Hotel Manager', ' performs administrative work for the manager', 44000, 'excellent written, oral communication,strong leadership skills'),
 (02, 'Housekeeping', 'to clean guest rooms, wash bedding and towels, replace toiletries and clean other areas', 23700, 'organization and laundry skills'),
 (03, 'Waiter/Waitress', 'to take guests orders, and serve the meals, making sure they have everything they need', 20500, 'verbal communication,food safety and teamwork'),
 (04, 'Room Service', 'to take room service orders, and then to deliver for them', 27000, 'exceptional hotel room service experience'),
 (05, 'Front Desk Clerk', 'to verify a guest reservation, take phone call and make reservation', 24500, 'excellent written, oral communication'),
 (06, 'Executive Chef', 'to plan the menus for all meals', 51800, 'Great cooking skills and attention to detail,Leadership and management skills'),
 (07, 'Accounting', 'to check hotel recording of income and expenses, paying its bills, taxes, and employees', 63000, 'analytical,communication and interpersonal skills'),
 (08, 'Marketing and Advertising', 'promotion of the hotel in society through various advertising channels', 79000, 'interpersonal,communication and creativity skills'),
 (09, 'Front Desk Supervisor', 'manage front desk workers,check that customers are greeted warmly and checked in efficiently', 32000, 'management,excellent verbal and written communication skills'),
 (10, 'Kitchen Staff', 'cooking, washing dishes, preparing salads, ordering supplies, planning menus and etc.', 31000, 'excellent organizational, time management, and multitasking abilities');

INSERT INTO Employees (EmployeeID, name, surname, contact, working_experience, marital_status,salary,JobID,ManagerID,HotelID)
VALUES
 (21001, 'Frieda', 'Chaldecott', '8052532201', 4, 'single',45000,01,10101,101),
 (21002, 'Hurley', 'Moakes', '8461510059', 9, 'divorced',30000,02,10101,101),
 (21003, 'Lind', 'Roon', '8998091456', 9, 'married',23000,03,10102,102),
 (21004, 'Shelby', 'Kinnen', '8340365723', 7, 'single',30000,04,10103,103),
 (21005, 'Guido', 'Jinkinson', '8242772031', 3, 'single',25000,05,10104,104),
 (21006, 'Nell', 'Chatelain', '8757706690', 5, 'married',53000,06,10105,105),
 (21007, 'Artus', 'Cunio', '8525275975', 8, 'married',65000,07,10106,106),
 (21008, 'Carney', 'McDonald', '8146742291', 7, 'married',80000,08,10107,107),
 (21009, 'Levi', 'Pizey', '8988843075', 10, 'divorced',34000,09,10108,108),
 (21010, 'Rozamond', 'Tosdevin', '8382900769', 1, 'single',32000,10,10109,109),
 (21011, 'Shelly', 'Dredge', '8543203678', 3, 'married',26000,05,10110,110),
 (21012, 'Emmerich', 'Cumberledge', '8219291095', 4, 'single',29000,04,10111,110),
 (21013, 'Elberta', 'Found', '8690326663', 9, 'married',23000,03,10112,102),
 (21014, 'Ursola', 'Ormesher', '8668972255', 6, 'widowed',25200,02,10111,110),
 (21015, 'Debor', 'Cottham', '8659008723', 8, 'married',47300,01,10112,102),
 (21016, 'Jamie', 'Tunnock', '8235705685', 3, 'married',40000,10,10106,106);

 INSERT INTO Room(RoomID,number_of_beds,type,rate,price,HotelID) VALUES
 (1,1,'Economy',2.5,50,101),
 (2,2,'Standart',3.5,80,102),
 (3,1,'Economy',2.3,60,103),
 (4,4,'Lux',5,150,101),
 (5,3,'Standart+',4.5,120,104),
 (6,2,'Standart',3.8,70,104),
 (7,3,'Standart+',4.5,120,105),
 (8,1,'Economy',2,40,106),
 (9,3,'Standart+',4,140,107),
 (10,4,'Lux',5,200,108),
 (11,4,'Lux',4,180,109),
 (12,3,'Standart+',3,100,110),
 (13,2,'Standart',3.5,90,105),
 (14,1,'Economy',2.5,50,107),
 (15,1,'Economy',2.5,75,108),
 (16,4,'Lux',5,210,110),
 (17,3,'Standart+',4.8,140,102);

  INSERT INTO Reservation (ReservationID,number_of_day,RoomID,HotelID) VALUES
 (10,3,1,101),
 (11,10,2,102),
 (12,1,3,103),
 (13,7,4,101),
 (14,2,5,104),
 (15,5,6,104),
 (16,11,7,105),
 (17,23,8,106),
 (18,13,9,107),
 (19,14,10,108),
 (20,18,11,109),
 (21,8,12,110),
 (22,3,13,105),
 (23,2,14,107),
 (24,3,15,108),
 (25,1,16,110),
 (26,5,17,102);

 INSERT INTO Users (UserID, name, surname, gender, contact_number,HotelID,reservationID) VALUES
 (1501, 'Natalee', 'Jelly', 'Female', '89037672339',101,10),
 (1502, 'Gabriela', 'Darcy', 'Female', '89811300172',102,11),
 (1503, 'Waneta', 'Jeffery', 'Female', '8771921203',103,12),
 (1504, 'Bengt', 'Egiloff', 'Male', '89037672527',101,13),
 (1505, 'Darrell', 'Mawby', 'Male', '8608428756',104,14),
 (1506, 'Armando', 'Manuello', 'Male', '8371312457',104,15),
 (1507, 'Faulkner', 'Harkes', 'Male', '8382359340',105,16),
 (1508, 'Justin', 'Lampel', 'Male', '8458808919',106,17),
 (1509, 'Matthus', 'Ivakin', 'Male', '8910767839',107,18),
 (1510, 'Dyane', 'Lorkins', 'Female', '89811318625',108,19),
 (1511, 'Delcina', 'Whatman', 'Female', '8251561864',109,20),
 (1512, 'Inger', 'Bertolaccini', 'Male', '8625334890',110,21),
 (1513, 'Issie', 'Tomley', 'Female', '8720868383',105,22),
 (1514, 'Muriel', 'Scholl', 'Female', '8914704992',107,23),
 (1515, 'Lucio', 'Lennox', 'Male', '87272585444',108,24),
 (1516, 'Frazer', 'Markos', 'Male', '8232180733',110,25),
 (1517, 'Rene', 'Redd', 'Female', '89831264444',102,26);

INSERT INTO AdditionalServices (ServiceID , name , description, price , age_limitations) VALUES
 (901 , 'All-Day Breakfast and Brunch', 'breakfast available throughout the entire day', '$15', 'for all'),
 (902, 'Pick-Up/Drop-Off Service', 'Creating a regular schedule for guests', '$9', 'for all'),
 (903, 'Caring ', 'free bottle of water,small pack of mints, or puzzle', 'free', 'for all'),
 (904, 'Rental Clothing', 'offer a temporary closet to  guests ', '$11', 'from the age of 16'),
 (905, 'Morning call', 'If you want to be woken, ask our staff to call you in the morning at the appointed time', '$2', 'for all'),
 (906, 'FLOWERS', 'to order flowers to the room', '$15', 'for all'),
 (907, 'Extra bed', 'one extra bed(a cot) could be added to the rooms', '$4', 'for all'),
 (908, 'Mini Bar', ' mini bar with a big collection of alcoholic and non-alcoholic drinks and food', 'with mini bar table', 'from the age of 18'),
 (909, 'Car rental', 'to rent a car', 'starts from $70', 'from the age of 18'),
 (910, 'Luggage storage', 'to storage baggage', 'starts from $10', 'from the age of 16');
 insert into hotel_service values
 (901,101),
 (902,102),
 (903,103),
 (904,104),
 (905,105),
 (906,106),
 (907,107),
 (908,108),
 (909,109),
 (910,110),
 (910,109),
 (909,108),
 (908,107),
 (907,106),
 (906,105),
 (905,104);
 insert into Restaurants(restaurantid,floor,number_of_tables,hotelid) values
 (1,'1st floor','25',101),
 (2,'2nd floor','30',102),
 (3,'1st floor','40',103),
 (4,'2nd floor','35',104),
 (5,'3rd floor','20',105),
 (6,'1st floor','25',106),
 (7,'2nd floor','40',107),
 (8,'3rd floor','15',108),
 (9,'4th floor','25',109),
 (10,'1st floor','15',110);

 insert into Menu(DishID,name,description,price,RestaurantID) values
 (1,'Steak','A steak is a meat generally sliced across the muscle fibers, potentially including a bone.',50,1),
 (2,'Omelet','An omelette or omelet is a dish made from beaten eggs, fried with butter or oil in a frying pan.',5,2),
 (3,'Caesar salad','A Caesar salad is a green salad of romaine lettuce and croutons dressed with lemon juice , olive oil, egg, Worcestershire sauce, anchovies, garlic, Dijon mustard, Parmesan cheese, and black pepper.',15,3),
 (4,'French fries','French fries or simply fries or chips, are pieces of potato that have been deep-fried.',7,4),
 (5,'Okroshka','The classic soup is a mix of mostly raw vegetables , boiled potatoes, eggs, and a cooked meat such as beef, veal, sausages, or ham with kvass.',9,5),
 (6,'Lasagna','Lasagne, or the singular lasagna, is an Italian dish made of stacked layers of thin flat pasta alternating with fillings such as ragu and other vegetables, cheese',20,6),
 (7,'Maqluba','It consists of meat, rice, and fried vegetables placed in a pot which is flipped upside down when served.',40,7),
 (8,'Pizza','Pizza, dish of Italian origin consisting of many spice',18,8),
 (9,'Shrimp','Shrimp with the creamy garlic sauce',17,9),
 (10,'Nuggets','A chicken product made from chicken meat that is breaded or battered, then deep-fried or baked.',5,10),
 (11,'Sushi','Sushi is a popular Japanese dish made from seasoned rice with fish, egg, or vegetables. A sushi roll is shaped inside a thin sheet of seaweed.',15,10),
 (12,'Potatoes with mushrooms','Potatoes with mushrooms in a creamy sauce',25,2),
 (13,'Ice cream with nuts','Ice cream is a sweetened frozen food with nuts.',10,5),
 (14,'Kimchi with rice','a spicy pickled or fermented mixture containing cabbage, onions, and sometimes fish, variously seasoned, as with garlic, horseradish.',24,6),
 (15,'Dolma','A dish of tomatoes, green peppers, vine leaves, or eggplants stuffed with a mixture of meat, rice, and spices.',20,1),
 (16,'Pilaf','A steamed rice dish often with meat, shellfish, or vegetables in a seasoned broth.',30,8);
 insert into DishUser(ID,DishID,UserID) values
 (1,1,1501),
 (2,2,1517),
 (3,3,1503),
 (4,4,1506),
 (5,5,1513),
 (6,6,1508),
 (7,7,1514),
 (8,8,1515),
 (9,9,1511),
 (10,10,1516),
 (11,11,1512),
 (12,12,1502),
 (13,13,1507),
 (14,14,1508),
 (15,15,1501),
 (16,16,1515),
 (17,4,1507),
 (18,12,1502);

 insert into UserService(ID,ServiceID,UserID) values
 (1,901,1501),
 (2,902,1502),
 (3,903,1503),
 (4,904,1505),
 (5,905,1507),
 (6,906,1508),
 (7,907,1509),
 (8,908,1510),
 (9,909,1501),
 (10,910,1512),
 (11,910,1516),
 (12,909,1501),
 (13,908,1515),
 (14,907,1514),
 (15,906,1508),
 (16,905,1513),
 (17,904,1505),
 (18,903,1503),
 (19,902,1517),
 (20,901,1504);

 --Find number of Natalee Jelly--
 select contact_number from Users inner join
 DishUser on DishUser.UserID=Users.UserID
 where name='Natalee' and surname = 'Jelly'
 group by Users.UserID;

 --Show information who used Morning call additional service--
 select Hotel.name,Users.name,Users.contact_number,AdditionalServices.name,AdditionalServices.price,AdditionalServices.age_limitations
 from Hotel
 inner join Users
 on Users.HotelID = Hotel.HotelID
 inner join UserService
 on Users.UserID = UserService.UserID
 inner join AdditionalServices
 on UserService.ServiceID = AdditionalServices.ServiceID
 where AdditionalServices.name = 'Morning call';

 UPDATE Restaurants
 SET name = 'Dinner in the Sky'
 WHERE RestaurantID = 1;

 UPDATE Restaurants
 SET name = 'The Lockhart'
 WHERE RestaurantID = 2;

 UPDATE Restaurants
 SET name = 'El Diablo “The Devil”'
 WHERE RestaurantID = 3;

 UPDATE Restaurants
 SET name = 'Eternity'
 WHERE RestaurantID = 4;

 UPDATE Restaurants
 SET name = 'O.NOIR'
 WHERE RestaurantID = 5;

 UPDATE Restaurants
 SET name = 'Aurum'
 WHERE RestaurantID = 6;

 UPDATE Restaurants
 SET name = 'Kinderkookkafe'
 WHERE RestaurantID = 7;

 UPDATE Restaurants
 SET name = 'Steam Plant'
 WHERE RestaurantID = 8;

 UPDATE Restaurants
 SET name = 'Chill Out'
 WHERE RestaurantID = 9;

 UPDATE Restaurants
 SET name = 'Villa Escudero'
 WHERE RestaurantID = 10;

 --Display each restaurant's cheapest dish--
 select Hotel.name,Restaurants.name,Menu.name,Menu.price
 from Hotel
 inner join Restaurants
 on Hotel.HotelID = Restaurants.HotelID
 inner join Menu
 on Restaurants.RestaurantID = Menu.RestaurantID
 WHERE Menu.price = (SELECT MIN(Menu.price)FROM Menu WHERE Menu.RestaurantID = Restaurants.RestaurantID);

 --Show information about worker whose working experience more than 5 years--
 select JobDescription.name,Employees.name,Employees.surname,Employees.salary,JobDescription.skills,Employees.working_experience
 from Employees
 inner join JobDescription
 on Employees.JobID = JobDescription.JobID
 where Employees.working_experience::integer>5;

 UPDATE JobDescription
 SET salary_range = '44000-70000'
 WHERE JobID = 1;

 UPDATE JobDescription
 SET salary_range = '23700-45000'
 WHERE JobID = 2;

 UPDATE JobDescription
 SET salary_range = '20500-30000'
 WHERE JobID = 3;

 UPDATE JobDescription
 SET salary_range = '27000-40000'
 WHERE JobID = 4;

 UPDATE JobDescription
 SET salary_range = '24500-35000'
 WHERE JobID = 5;

 UPDATE JobDescription
 SET salary_range = '51800-72000'
 WHERE JobID = 6;

 UPDATE JobDescription
 SET salary_range = '63000-78000'
 WHERE JobID = 7;

 UPDATE JobDescription
 SET salary_range = '79000-90000'
 WHERE JobID = 8;

 UPDATE JobDescription
 SET salary_range = '32000-55000'
 WHERE JobID = 9;

 UPDATE JobDescription
 SET salary_range = '31000-50000'
 WHERE JobID = 10;

 --Update employee's salary whose working experience more than 5 years--
 update Employees set salary = salary*1.2
 where Employees.working_experience::integer>5;

 DELETE FROM Managers
 WHERE HotelID is NULL;

 -- Show information about Male users who are live only in 4.5 and higher stars hotels--
 SELECT users.name, users.surname, users.contact_number, users.gender
 FROM users
 WHERE users.gender = 'Male'
 AND users.hotelid IN (
    SELECT hotel.HotelID
    FROM hotel
    WHERE rate >= 4.5
 );

 -- Show additional services that are available for all in every hotel--
 SELECT Hotel.name, AdditionalServices.name,AdditionalServices.description
 FROM hotel
 INNER JOIN hotel_service on Hotel.HotelID = hotel_service.HotelID
 INNER JOIN AdditionalServices on hotel_service.ServiceID = AdditionalServices.ServiceID
 WHERE AdditionalServices.age_limitations = 'for all';

 -- Show employees whose managers have less than 4 years working experience--
SELECT *
FROM Employees
WHERE Employees.ManagerID IN (
    SELECT Managers.ManagerID
    FROM managers
    WHERE Managers.working_experience::integer < 4
);

--Show detailed info about all reservations in hotel "Atlantic Hotel"--
SELECT Hotel.name,
       Hotel.reception_number,
       Room.RoomID,
       Room.price,
       Reservation.number_of_day,
       Users.name,
       Users.surname,
       Users.contact_number
FROM hotel
         INNER JOIN Reservation on Hotel.HotelID = Reservation.HotelID
         INNER JOIN Room on Reservation.RoomID = Room.RoomID
         INNER JOIN Users on Reservation.ReservationID = Users.ReservationID
WHERE Hotel.name = 'Atlantic Hotel'
ORDER BY Users.name,
         Room.price,
         Reservation.number_of_day;

 -- Show bill without additional services for user with ID 1513--
SELECT Users.name,
       Users.surname,
       (SELECT (SUM(Room.price) * Reservation.number_of_day) AS "Total living cost"
        FROM Room
                 INNER JOIN Reservation ON Room.RoomID = Reservation.RoomID
                 INNER JOIN Users ON Reservation.ReservationID = Users.ReservationID
        WHERE Users.UserID = 1513
        GROUP BY Reservation.number_of_day),
       (SELECT SUM(menu.price) AS "Total dishes cost"
        FROM menu
                 INNER JOIN dishuser on Menu.DishID = dishuser.dishid
        WHERE DishUser.UserID = 1513)
FROM Users
WHERE Users.UserID = 1513;

--Show Managers with the lowest salary and Employee with the lowest salary that are managed by each of those managers
SELECT Employees.EmployeeID,
       Employees.name AS "Employee name",
       Employees.surname AS "Employee surname",
       Employees.salary AS "Employee salary",
       m.ManagerID,
       m.name AS "Manager name",
       m.surname AS "Manager surname",
       m.salary AS "Manager salary"
FROM Employees
LEFT JOIN (
    SELECT Managers.ManagerID,
           Managers.name,
           Managers.surname,
           Managers.salary
    FROM Managers
    WHERE Managers.salary = (SELECT MIN(Managers.salary) FROM Managers)
) AS m ON Employees.ManagerID = m.ManagerID
WHERE Employees.salary = (
    SELECT MIN(Employees.salary)
    FROM Employees
    WHERE Employees.ManagerID = m.ManagerID);

-- Show number of "Standart+" rooms in every hotel
SELECT Hotel.name,
       COUNT(Room.*) AS "Standart+ amount"
FROM Hotel
JOIN Room ON Hotel.HotelID = Room.HotelID
WHERE Room.type = 'Standart+'
GROUP BY Hotel.name
ORDER BY "Standart+ amount";

-- Show the hotel users in hotel with ID 105
SELECT Users.*
FROM Users
WHERE Users.HotelID = 105;

-- Show address and reception number in hotel where user with ID 1510 lives
SELECT Hotel.address,
       Hotel.reception_number
FROM Users
JOIN Hotel ON Users.HotelID = Hotel.HotelID
WHERE Users.UserID = 1510;

-- Show average bill for each restaurant
SELECT Restaurants.name,
       AVG(Menu.price) AS "Average bill"
FROM Restaurants
         JOIN Menu ON Restaurants.RestaurantID = Menu.RestaurantID
GROUP BY Restaurants.name
ORDER BY "Average bill" DESC, Restaurants.name;

--Update price column where type Lux to 50 percent--
UPDATE Room
SET price = price * 1.5
WHERE type = 'Lux';

-- Set hotel rate 5 for hotels with rate greater than 4.5
UPDATE hotel
SET rate = 5.0
WHERE rate > 4.5;

--Update manager's contact_number whose managerID is 10111--
UPDATE managers
set contact_number = '(561) 758-4567'
WHERE ManagerID = 10111;

--Add 5 days to reservation for hotels that have less than 4 stars--
UPDATE reservation
SET number_of_day = number_of_day + 5
WHERE hotelid NOT IN (
    SELECT hotelid
    FROM hotel
    WHERE rate > 4)

select * from users;

UPDATE users
SET name = 'Naruto',surname = 'Uzumaki',gender = 'Male'
WHERE userID = 1502;

--Update salary range for Executive Chef
UPDATE jobdescription
SET salary_range = '55000-80000'
WHERE name = 'Executive Chef';

--Update price of Additional services that cost $15
UPDATE additionalservices
SET price = '$20'
WHERE price = '$15';

--Delete additional services that have age limitation from 18 years old
DELETE FROM additionalservices
WHERE age_limitations = 'from the age of 18';

--Delete services for hotels with age limitation from 18 years old
DELETE FROM hotel_service
WHERE serviceid IN (
    SELECT serviceid
    FROM additionalservices
    WHERE age_limitations = 'from the age of 18'
);

--Delete services for users with age limitation from 18 years old
DELETE FROM userservice
WHERE serviceid IN (
    SELECT serviceid
    FROM additionalservices
    WHERE age_limitations = 'from the age of 18'
);

--Delete employees whose managers have less than 4 years working experience
DELETE FROM employees
WHERE managerid NOT IN (
    SELECT managerid
    FROM managers
    WHERE working_experience::integer < 4
);

--Delete managers who have less than 4 years working experience
DELETE FROM managers
WHERE working_experience::integer < 4;

--Delete user services where user name starts with letter "D"
DELETE FROM userservice
WHERE UserID IN (
    SELECT userid
    FROM users
    WHERE name LIKE 'D%');

--Delete user dishes where user name starts with letter "D"
DELETE FROM dishuser
WHERE UserID IN (
    SELECT userid
    FROM users
    WHERE name LIKE 'D%');

--Delete users whose name starts with letter "D"
DELETE FROM users
WHERE name LIKE 'D%';

--Delete reservations that are not belong to any user
DELETE FROM reservation
WHERE reservationid NOT IN (
    SELECT reservationid
    FROM users
);

--Delete from records from dish user where dish costs more than 35
DELETE FROM dishuser
WHERE dishid IN (
    SELECT Menu.DishID
    FROM menu
    WHERE price > 35
);

--Delete dishes that cost more than 35
DELETE FROM menu
WHERE price > 35;

--Delete restaurants that does not have any dishes
DELETE FROM restaurants
WHERE restaurantid NOT IN (
    SELECT restaurantid
    FROM menu
);

--Delete rooms that are not reserved by anyone
DELETE FROM room
WHERE roomid NOT IN (
    SELECT roomid
    FROM reservation
);

--Delete job description for jobs that nobody works
DELETE FROM jobdescription
WHERE jobid NOT IN (
    SELECT jobid
    FROM employees
);