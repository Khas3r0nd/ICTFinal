/*1*/ALTER TABLE Reservation ADD PRIMARY KEY (ReservationID);

/*2*/ALTER TABLE Restaurants
 ALTER COLUMN HotelID set not null;

 ALTER TABLE Employees
 ADD COLUMN satisfied boolean;

 /*3*/ALTER TABLE Employees
 DROP COLUMN satisfied;

 --Create new column with datatype varchar--
 ALTER TABLE Restaurants
 ADD COLUMN name varchar;

 --Change name salary to salary_range and change it's datatype
 /*4*/ALTER TABLE JobDescription RENAME COLUMN salary TO salary_range;

 /*5*/ALTER TABLE JobDescription
 ALTER COLUMN salary_range TYPE VARCHAR;