 --1.Find number of Natalee Jelly--
 select contact_number from Users inner join
 DishUser on DishUser.UserID=Users.UserID
 where name='Natalee' and surname = 'Jelly'
 group by Users.UserID;

  --2.Show information who used Morning call additional service--
 select Hotel.name,Users.name,Users.contact_number,AdditionalServices.name,AdditionalServices.price,AdditionalServices.age_limitations
 from Hotel
 inner join Users
 on Users.HotelID = Hotel.HotelID
 inner join UserService
 on Users.UserID = UserService.UserID
 inner join AdditionalServices
 on UserService.ServiceID = AdditionalServices.ServiceID
 where AdditionalServices.name = 'Morning call';

 --3.Show information about worker whose working experience more than 5 years--
 select JobDescription.name,Employees.name,Employees.surname,Employees.salary,JobDescription.skills,Employees.working_experience
 from Employees
 inner join JobDescription
 on Employees.JobID = JobDescription.JobID
 where Employees.working_experience::integer>5;

 --4.Show additional services that are available for all in every hotel--
 SELECT Hotel.name, AdditionalServices.name,AdditionalServices.description
 FROM hotel
 INNER JOIN hotel_service on Hotel.HotelID = hotel_service.HotelID
 INNER JOIN AdditionalServices on hotel_service.ServiceID = AdditionalServices.ServiceID
 WHERE AdditionalServices.age_limitations = 'for all';

 --5.Show detailed info about all reservations in hotel "Atlantic Hotel"--
SELECT Hotel.name,
       Hotel.reception_number,
       Room.RoomID,
       Room.price,
       Reservation.number_of_day,
       Users.name,
       Users.surname,
       Users.contact_number
FROM hotel
         INNER JOIN Reservation on Hotel.HotelID = Reservation.HotelID
         INNER JOIN Room on Reservation.RoomID = Room.RoomID
         INNER JOIN Users on Reservation.ReservationID = Users.ReservationID
WHERE Hotel.name = 'Atlantic Hotel'
ORDER BY Users.name,
         Room.price,
         Reservation.number_of_day;

 --6.Show number of "Standart+" rooms in every hotel
SELECT Hotel.name,
       COUNT(Room.*) AS "Standart+ amount"
FROM Hotel
JOIN Room ON Hotel.HotelID = Room.HotelID
WHERE Room.type = 'Standart+'
GROUP BY Hotel.name
ORDER BY "Standart+ amount";

--7.Show the hotel users in hotel with ID 105
SELECT Users.*
FROM Users
WHERE Users.HotelID = 105;

--8.Show address and reception number in hotel where user with ID 1510 lives
SELECT Hotel.address,
       Hotel.reception_number
FROM Users
JOIN Hotel ON Users.HotelID = Hotel.HotelID
WHERE Users.UserID = 1510;

--9.Show average bill for each restaurant
SELECT Restaurants.name,
       AVG(Menu.price) AS "Average bill"
FROM Restaurants
         JOIN Menu ON Restaurants.RestaurantID = Menu.RestaurantID
GROUP BY Restaurants.name
ORDER BY "Average bill" DESC, Restaurants.name;

--10.Show restaurants and hotel that are on the 2nd floor and have number of tables more or equal to 35
SELECT Restaurants.name AS "Restaurant",
       Hotel.name AS "Hotel"
FROM Restaurants
JOIN Hotel ON Restaurants.HotelID = Hotel.HotelID
WHERE Restaurants.floor = '2nd floor'
AND Restaurants.number_of_tables::integer >= 35;


