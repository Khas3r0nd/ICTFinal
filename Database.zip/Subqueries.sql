 --1.Display each restaurant's cheapest dish--
 select Hotel.name,Restaurants.name,Menu.name,Menu.price
 from Hotel
 inner join Restaurants
 on Hotel.HotelID = Restaurants.HotelID
 inner join Menu
 on Restaurants.RestaurantID = Menu.RestaurantID
 WHERE Menu.price = (SELECT MIN(Menu.price)FROM Menu WHERE Menu.RestaurantID = Restaurants.RestaurantID);

  --2.Show information about Male users who are live only in 4.5 and higher stars hotels--
 SELECT users.name, users.surname, users.contact_number, users.gender
 FROM users
 WHERE users.gender = 'Male'
 AND users.hotelid IN (
    SELECT hotel.HotelID
    FROM hotel
    WHERE rate >= 4.5
 );

 --3.Show employees whose managers have less than 4 years working experience--
SELECT *
FROM Employees
WHERE Employees.ManagerID IN (
    SELECT Managers.ManagerID
    FROM managers
    WHERE Managers.working_experience::integer < 4
);

 --4.Show bill without additional services for user with ID 1513--
SELECT Users.name,
       Users.surname,
       (SELECT (SUM(Room.price) * Reservation.number_of_day) AS "Total living cost"
        FROM Room
                 INNER JOIN Reservation ON Room.RoomID = Reservation.RoomID
                 INNER JOIN Users ON Reservation.ReservationID = Users.ReservationID
        WHERE Users.UserID = 1513
        GROUP BY Reservation.number_of_day),
       (SELECT SUM(menu.price) AS "Total dishes cost"
        FROM menu
                 INNER JOIN dishuser on Menu.DishID = dishuser.dishid
        WHERE DishUser.UserID = 1513)
FROM Users
WHERE Users.UserID = 1513;

--5.Show Managers with the lowest salary and Employee with the lowest salary that are managed by each of those managers
SELECT Employees.EmployeeID,
       Employees.name,
       Employees.surname,
       Employees.salary,
       m.ManagerID,
       m.name,
       m.surname,
       m.salary
FROM Employees
LEFT JOIN (
    SELECT Managers.ManagerID,
           Managers.name,
           Managers.surname,
           Managers.salary
    FROM Managers
    WHERE Managers.salary = (SELECT MIN(Managers.salary) FROM Managers)
) AS m ON Employees.ManagerID = m.ManagerID
WHERE Employees.salary = (
    SELECT MIN(Employees.salary)
    FROM Employees
    WHERE Employees.ManagerID = m.ManagerID)